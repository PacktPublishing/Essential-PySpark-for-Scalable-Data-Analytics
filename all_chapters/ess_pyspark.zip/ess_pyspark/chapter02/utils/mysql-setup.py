# Databricks notebook source
# MAGIC %md ###Utility notebook to install MySQL Server
# MAGIC This notebook:
# MAGIC 1. Installs a `mysql-server` locally on your `driver` node.
# MAGIC 2. Creates a database called `pysparkdb`.
# MAGIC 3. Creates a table called `authors` and inserts some sample data.

# COMMAND ----------

# MAGIC %sh
# MAGIC sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password password root'
# MAGIC sudo debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password root'
# MAGIC sudo apt-get -y install mysql-server
# MAGIC service mysql restart

# COMMAND ----------

# MAGIC %sh service mysql status

# COMMAND ----------

# MAGIC %sh 
# MAGIC mysql -u root -proot -e "create database pysparkdb;"
# MAGIC mysql -u root -proot -e """drop table if exists pysparkdb.authors; 
# MAGIC CREATE TABLE pysparkdb.authors (
# MAGIC   uid INT NOT NULL AUTO_INCREMENT,
# MAGIC   last_name VARCHAR( 50 ),
# MAGIC   first_name VARCHAR( 50 ),
# MAGIC   birth_month VARCHAR( 50 ),
# MAGIC   PRIMARY KEY (uid)
# MAGIC )"""

# COMMAND ----------

# MAGIC %sh mysql -u root -proot -e """
# MAGIC INSERT INTO pysparkdb.authors (last_name, first_name, birth_month)
# MAGIC VALUES
# MAGIC   ('Asimov', 'Issac', 'January'),
# MAGIC   ('Brown', 'Dan', 'June'),
# MAGIC   ('Baldacci', 'David', 'August'),
# MAGIC   ('Burroughs', 'Edgar Rice', 'September'),
# MAGIC   ('Clarke', 'Arthur C.', 'December'),
# MAGIC   ('Cook', 'Robin', 'May'),
# MAGIC   ('Dickens', 'Charles', 'February'),
# MAGIC   ('Forster', 'E.M.', 'January'),
# MAGIC   ('Lahiri', 'Jhumpa', 'July'),
# MAGIC   ('Rand', 'Ayn', 'February'),
# MAGIC   ('Salinger', 'J.D.', 'January'),
# MAGIC   ('Seuss', 'Dr.', 'March'),
# MAGIC   ('Stoker', 'Bram', 'November'),
# MAGIC   ('Wilde', 'Oscar', 'October'),
# MAGIC   ('Wordsworth', 'William', 'April');
# MAGIC """

# COMMAND ----------

# MAGIC %sh mysql -u root -proot -e "use pysparkdb; show tables;"

# COMMAND ----------

# MAGIC %sh mysql -u root -proot -e "select * from pysparkdb.authors;"