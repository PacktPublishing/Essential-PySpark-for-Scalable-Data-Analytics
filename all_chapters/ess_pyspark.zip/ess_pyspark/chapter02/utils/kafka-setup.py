# Databricks notebook source
# MAGIC %md ###Utility notebook to install Kafka Server
# MAGIC This notebook:
# MAGIC 1. Installs a `kafka service` locally on your `driver` node.
# MAGIC 2. Creates a topic called `pyspark`.
# MAGIC 3. Loads sample data into the topic.

# COMMAND ----------

# %sh wget https://archive.apache.org/dist/kafka/0.10.2.1/kafka_2.12-0.10.2.1.tgz

# COMMAND ----------

# MAGIC %sh wget --no-check-certificate --no-proxy https://snudurupati.s3.us-west-2.amazonaws.com/kafka_2.12-0.10.2.1.tgz

# COMMAND ----------

# MAGIC %sh tar -xvf kafka*.tgz

# COMMAND ----------

# MAGIC %sh 
# MAGIC cd kafka_2.12-0.10.2.1
# MAGIC bin/zookeeper-server-start.sh -daemon config/zookeeper.properties
# MAGIC bin/kafka-server-start.sh -daemon config/server.properties

# COMMAND ----------

# MAGIC %sh sleep 20

# COMMAND ----------

# MAGIC %sh 
# MAGIC nc -vz localhost 2181
# MAGIC nc -vz localhost 9092

# COMMAND ----------

# MAGIC %sh 
# MAGIC cat logs/stderr

# COMMAND ----------

#%sh kafka_2.12-0.10.2.1/bin/kafka-console-producer.sh --broker-list localhost:9092 --topic wordcount < logs/stderr

# COMMAND ----------

csv_df = (spark
                 .read
                   .option("header", "true")
                   .option("inferSchema", "true")
                   .csv("/FileStore/shared_uploads/online_retail/online_retail_II.csv")
            )
retail_df = csv_df.selectExpr("Invoice as InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate", "Price as UnitPrice", "`Customer ID` as CustomerID", "Country")
retail_df.show()

# COMMAND ----------

from pyspark.sql.functions import to_json, struct, from_json, monotonically_increasing_id
from pyspark.sql.types import StructType, StructField, StringType

kafka_df = retail_df.withColumn("key", monotonically_increasing_id().cast("STRING")).withColumn("value", to_json(struct([retail_df[x] for x in retail_df.columns])).cast("STRING"))

jsonSchema = StructType([ StructField("eventName", StringType(), True),
                          StructField("eventParams", StringType(), True)
                        ])
kafka_df.select("key", "value").show()

# COMMAND ----------

# MAGIC %md Write retail events to `retail_events` Kafka topic.

# COMMAND ----------

(kafka_df.select("key", "value")
 .write
  .format("kafka")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("topic", "retail_events")
  .save()
)