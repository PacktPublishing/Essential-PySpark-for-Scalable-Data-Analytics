# Databricks notebook source
# MAGIC %sh nc -vz localhost 3306

# COMMAND ----------

# MAGIC %md Check that MySQl JDBC Driver is installed and available

# COMMAND ----------

# MAGIC %scala Class.forName("org.mariadb.jdbc.Driver")

# COMMAND ----------

wordcount_df = spark.createDataFrame(
    [("data", 10), ("parallel", 2), ("Processing", 30), ("Spark", 50), ("Apache", 10)],
    ("word", "count"))
wordcount_df.show()

# COMMAND ----------

wordcount_df.write.format("jdbc").options(
    url="jdbc:mysql://localhost:3306/pysparkdb",
    driver = "org.mariadb.jdbc.Driver",
    dbtable = "word_counts",
    user="root",
    password="root").save()