# Databricks notebook source
# MAGIC %md Serving Layer

# COMMAND ----------

batch_df = spark.read.parquet("/tmp/data-lake/online_retail.parquet")
speed_df = spark.read.parquet("/tmp/data-lake/retail_events.parquet").drop("EventDate").drop("EventTime")
serving_df = batch_df.union(speed_df)
serving_df.createOrReplaceGlobalTempView("serving_layer")

# COMMAND ----------

# MAGIC %md Ad-hoc queries on Serving Layer.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT count(*) FROM global_temp.serving_layer;