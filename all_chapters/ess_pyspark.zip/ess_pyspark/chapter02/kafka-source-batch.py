# Databricks notebook source
#from  pyspark.sql.functions import *
kafka_df = (spark.read
        .format("kafka")
        .option("kafka.bootstrap.servers", "localhost:9092")
        .option("subscribe", "wordcount")
        .option("startingOffsets", "earliest")
        .load()
        )
kafka_df.show()

# COMMAND ----------

