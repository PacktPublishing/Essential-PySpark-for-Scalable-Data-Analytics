# Databricks notebook source
# MAGIC %fs ls dbfs:/FileStore/shared_uploads/online_retail/

# COMMAND ----------

# MAGIC %fs ls /tmp/data-lake/

# COMMAND ----------

spark.conf.set("spark.sql.adaptive.enabled", "true")

# COMMAND ----------

retail_df = (spark
                 .read
                 .option("header", "true")
                 .option("inferSchema", "true")
                 .csv("/FileStore/shared_uploads/online_retail/online_retail.csv")
            )

# COMMAND ----------

retail_df.rdd.getNumPartitions()

# COMMAND ----------

(retail_df
       .write
       .mode("overwrite")
       .parquet("/tmp/data-lake/online_retail.parquet")
)

# COMMAND ----------

# MAGIC %fs ls /tmp/data-lake/online_retail.parquet

# COMMAND ----------

# MAGIC %md ####Clean-up 
# MAGIC **Databricks Community Edition** has a limitation of 10000 files and 10 GB of storage in DBFS.<br>
# MAGIC So it is prudent to clean-up any intermediate datasets created on DBFS that we do not intent to use at a later time.

# COMMAND ----------

# MAGIC %fs rm -r /tmp/data-lake/