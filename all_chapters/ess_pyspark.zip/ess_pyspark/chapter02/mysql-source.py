# Databricks notebook source
# MAGIC %sh nc -vz localhost 3306

# COMMAND ----------

# MAGIC %scala Class.forName("org.mariadb.jdbc.Driver")

# COMMAND ----------

dataframe_mysql = spark.read.format("jdbc").options(
    url="jdbc:mysql://localhost:3306/pysparkdb",
    driver = "org.mariadb.jdbc.Driver",
    dbtable = "authors",
    user="root",
    password="root").load()

# COMMAND ----------

dataframe_mysql.show()