# Databricks notebook source
wordcount_df = spark.createDataFrame(
    [("data", 10), ("parallel", 2), ("Processing", 30), ("Spark", 50), ("Apache", 10)],
    ("word", "count"))
wordcount_df.show()

# COMMAND ----------

(wordcount_df
        .write
        .option("header", "true")
        .mode("overwrite")
        .save("/tmp/data-lake/wordcount.csv")
)

# COMMAND ----------

# MAGIC %md ####Clean-up 
# MAGIC **Databricks Community Edition** has a limitation of 10000 files and 10 GB of storage in DBFS.<br>
# MAGIC So it is prudent to clean-up any intermediate datasets created on DBFS that we do not intent to use at a later time.

# COMMAND ----------

# MAGIC %fs rm -r /tmp/data-lake/wordcount.csv