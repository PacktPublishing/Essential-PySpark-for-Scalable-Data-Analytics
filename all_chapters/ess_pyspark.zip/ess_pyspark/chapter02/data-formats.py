# Databricks notebook source
# MAGIC %md ###Unstructured Files

# COMMAND ----------

# MAGIC %fs ls dbfs:/FileStore/FileStore/shared_uploads/images/

# COMMAND ----------

raw_df = spark.read.format("image").load("/FileStore/FileStore/shared_uploads/images/")
raw_df.printSchema()
image_df = raw_df.select("image.origin", "image.height", "image.width", "image.nChannels", "image.mode", "image.data")
image_df.write.option("header", "true").mode("overwrite").csv("/tmp/data-lake/images.csv")

# COMMAND ----------

from pyspark.sql.functions import max, lit
temp_df = final_df.withColumn("max_width", lit(final_df.agg(max("width")).first()[0]))
temp_df.where("width == max_width").show()

# COMMAND ----------

# MAGIC %fs ls dbfs:/tmp/data-lake/images.csv

# COMMAND ----------

# MAGIC %md ###Semi-Structured 

# COMMAND ----------

csv_df = spark.read.options(header="true", inferSchema="true").csv("/tmp/data-lake/images.csv")
csv_df.printSchema()
csv_df.show()

# COMMAND ----------

from pyspark.sql.functions import max, lit
temp_df = csv_df.withColumn("max_width", lit(csv_df.agg(max("width")).first()[0]))
temp_df.where("width == max_width").show()

# COMMAND ----------

# MAGIC %md ###Structured Data

# COMMAND ----------

final_df.write.parquet("/tmp/data-lake/images.parquet")
parquet_df = spark.read.parquet("/tmp/data-lake/images.parquet")
parquet_df.printSchema()
display(parquet_df)

# COMMAND ----------

from pyspark.sql.functions import max, lit
temp_df = parquet_df.withColumn("max_width", lit(parquet_df.agg(max("width")).first()[0]))
temp_df.where("width == max_width").show()

# COMMAND ----------

# MAGIC %fs ls /tmp/data-lake/images.parquet

# COMMAND ----------

# MAGIC %md ####Clean-up 
# MAGIC **Databricks Community Edition** has a limitation of 10000 files and 10 GB of storage in DBFS.<br>
# MAGIC So it is prudent to clean-up any intermediate datasets created on DBFS that we do not intent to use at a later time.

# COMMAND ----------

# MAGIC %fs rm -r /tmp/data-lake/images.parquet