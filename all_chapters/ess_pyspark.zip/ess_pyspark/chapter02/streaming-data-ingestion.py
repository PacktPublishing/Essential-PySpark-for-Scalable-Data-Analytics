# Databricks notebook source
# MAGIC %md Define data schema.

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DoubleType

eventSchema = ( StructType()
  .add('InvoiceNo', StringType()) 
  .add('StockCode', StringType())
  .add('Description', StringType()) 
  .add('Quantity', IntegerType()) 
  .add('InvoiceDate', StringType()) 
  .add('UnitPrice', DoubleType()) 
  .add('CustomerID', IntegerType()) 
  .add('Country', StringType())     
)

# COMMAND ----------

kafka_df = (spark
                 .readStream
                   .format("kafka")
                   .option("kafka.bootstrap.servers", "localhost:9092")
                   .option("subscribe", "retail_events")
                   .option("startingOffsets", "earliest")
                 .load()
            )

# COMMAND ----------

from pyspark.sql.functions import col, from_json, to_date

retail_df = (kafka_df
              .select(from_json(col("value").cast(StringType()), eventSchema).alias("message"), col("timestamp").alias("EventTime"))
              .select("message.*", "EventTime")
)

# COMMAND ----------

#%fs rm -r /tmp/data-lake/retail_events.parquet

# COMMAND ----------

base_path = "/tmp/data-lake/retail_events.parquet"

(retail_df
  .withColumn("EventDate", to_date(retail_df.EventTime))
    .writeStream
      .format('parquet')
      .outputMode("append")
      .trigger(once=True)
      .option('checkpointLocation', base_path + '/_checkpoint')
  .start(base_path)
)

# COMMAND ----------

# MAGIC %fs ls dbfs:/tmp/data-lake/retail_events.parquet