# Databricks notebook source
# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS word_counts;
# MAGIC CREATE TABLE word_counts (word STRING)
# MAGIC USING csv
# MAGIC OPTIONS("delimiter"=" ")
# MAGIC LOCATION "/databricks-datasets/README.md"

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT word, COUNT(word) AS count
# MAGIC FROM word_counts
# MAGIC GROUP BY word